"""
ISA PWA Backend
Intelligent Status Analytics - Backend API Module

This package contains the FastAPI backend server for the ISA PWA application.
It provides RESTful APIs for status monitoring, analytics, and data management.

Key Components:
- FastAPI server with async/await support
- MongoDB integration with Motor driver
- Pydantic models for data validation
- Comprehensive error handling
- Health checks and monitoring
- Background tasks support
- Production-ready configuration

Author: ISA Team
Version: 1.0.0
License: MIT
"""

__version__ = "1.0.0"
__author__ = "ISA Team"
__email__ = "team@isa-app.com"
__license__ = "MIT"

# Import main components for easy access
try:
    from .server import app, settings, APIService
    __all__ = ["app", "settings", "APIService"]
except ImportError:
    # Handle case where server dependencies aren't installed
    __all__ = []

# Package metadata
PACKAGE_INFO = {
    "name": "isa-backend",
    "version": __version__,
    "description": "ISA PWA Backend API Server",
    "author": __author__,
    "license": __license__,
    "python_requires": ">=3.11",
    "dependencies": [
        "fastapi>=0.110.1",
        "uvicorn>=0.25.0",
        "motor>=3.3.1", 
        "pymongo>=4.5.0",
        "pydantic>=2.6.4",
        "python-dotenv>=1.0.1",
        "python-multipart>=0.0.9"
    ]
}

def get_version():
    """Get the current version of the backend package."""
    return __version__

def get_package_info():
    """Get complete package information."""
    return PACKAGE_INFO.copy()

# Health check function that can be imported
def health_check():
    """Simple health check function for external monitoring."""
    try:
        return {
            "status": "healthy",
            "version": __version__,
            "package": "isa-backend"
        }
    except Exception:
        return {
            "status": "error", 
            "version": __version__,
            "package": "isa-backend"
        }