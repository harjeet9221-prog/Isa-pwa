#!/usr/bin/env python3
"""
ISA PWA - Intelligent Status Analytics
FastAPI Backend Server

A modern, production-ready API server with:
- MongoDB integration with Motor (async)
- Comprehensive error handling
- Request validation with Pydantic
- Health checks and monitoring
- CORS configuration
- Logging and metrics
- Background tasks support
- Rate limiting ready
- Security headers
"""

import os
import logging
import asyncio
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional, Dict, Any
from contextlib import asynccontextmanager

# FastAPI and related imports
from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

# Database and validation
from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from pydantic import BaseModel, Field, validator, EmailStr
from pymongo.errors import ConnectionFailure, OperationFailure
from pymongo import IndexModel, ASCENDING, DESCENDING

# Environment and configuration
from dotenv import load_dotenv
import json
from collections import defaultdict
import time

# Setup logging first
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('logs/app.log') if Path('logs').exists() else logging.NullHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load environment variables
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Configuration
class Settings:
    # Database
    MONGO_URL: str = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
    DB_NAME: str = os.getenv('DB_NAME', 'isa_db')
    
    # Server
    ENVIRONMENT: str = os.getenv('ENVIRONMENT', 'development')
    HOST: str = os.getenv('HOST', '0.0.0.0')
    PORT: int = int(os.getenv('PORT', 8000))
    
    # Security
    SECRET_KEY: str = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    JWT_ALGORITHM: str = os.getenv('JWT_ALGORITHM', 'HS256')
    ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv('ACCESS_TOKEN_EXPIRE_MINUTES', 30))
    
    # Features
    ENABLE_RATE_LIMITING: bool = os.getenv('ENABLE_RATE_LIMITING', 'false').lower() == 'true'
    MAX_REQUESTS_PER_MINUTE: int = int(os.getenv('MAX_REQUESTS_PER_MINUTE', 100))
    
    # Logging
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')

settings = Settings()

# Global variables
client: Optional[AsyncIOMotorClient] = None
db: Optional[AsyncIOMotorDatabase] = None
security = HTTPBearer(auto_error=False)

# Request rate limiting
request_counts = defaultdict(list)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Async context manager for app lifespan events"""
    # Startup
    global client, db
    logger.info("🚀 Starting ISA PWA API Server...")
    
    try:
        # Connect to MongoDB
        client = AsyncIOMotorClient(
            settings.MONGO_URL,
            serverSelectionTimeoutMS=3000,
            connectTimeoutMS=3000,
            maxPoolSize=10,
            retryWrites=True
        )
        db = client[settings.DB_NAME]
        
        # Test connection
        await client.admin.command('ping')
        logger.info(f"✅ Connected to MongoDB: {settings.DB_NAME}")
        
        # Setup database indexes
        await setup_database_indexes()
        logger.info("✅ Database indexes created")
        
        # Setup background tasks
        setup_background_tasks()
        logger.info("✅ Background tasks initialized")
        
    except Exception as e:
        logger.error(f"❌ Failed to connect to MongoDB: {e}")
        # Continue without DB for health checks
        
    logger.info("🎉 ISA PWA API Server started successfully")
    yield
    
    # Shutdown
    logger.info("🛑 Shutting down ISA PWA API Server...")
    if client:
        client.close()
        logger.info("✅ Database connection closed")

# Create FastAPI app
app = FastAPI(
    title="ISA API",
    description="Intelligent Status Analytics - API for monitoring and analytics",
    version="1.0.0",
    docs_url="/docs" if settings.ENVIRONMENT != "production" else None,
    redoc_url="/redoc" if settings.ENVIRONMENT != "production" else None,
    lifespan=lifespan
)

# Middleware setup
async def setup_middleware():
    """Setup application middleware"""
    
    # CORS - Allow frontend origins
    allowed_origins = [
        "http://localhost:3000",
        "http://localhost:3001", 
        "http://127.0.0.1:3000",
        "https://localhost:3000",
    ]
    
    if settings.ENVIRONMENT == "production":
        # Add production origins
        production_origins = os.getenv('ALLOWED_ORIGINS', '').split(',')
        allowed_origins.extend([origin.strip() for origin in production_origins if origin.strip()])
    else:
        # Allow all origins in development
        allowed_origins = ["*"]
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allowed_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["*"]
    )
    
    # Compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Trusted hosts in production
    if settings.ENVIRONMENT == "production":
        trusted_hosts = os.getenv('TRUSTED_HOSTS', 'localhost').split(',')
        app.add_middleware(
            TrustedHostMiddleware, 
            allowed_hosts=[host.strip() for host in trusted_hosts]
        )

# Setup middleware
asyncio.create_task(setup_middleware())

# Database setup
async def setup_database_indexes():
    """Create database indexes for optimal performance"""
    if not db:
        return
        
    try:
        # Status checks collection indexes
        status_checks_indexes = [
            IndexModel([("timestamp", DESCENDING)]),
            IndexModel([("client_name", ASCENDING)]),
            IndexModel([("timestamp", DESCENDING), ("client_name", ASCENDING)]),
            IndexModel([("id", ASCENDING)], unique=True),
        ]
        
        await db.status_checks.create_indexes(status_checks_indexes)
        logger.info("📊 Database indexes created successfully")
        
    except Exception as e:
        logger.error(f"❌ Failed to create database indexes: {e}")

# Background tasks
def setup_background_tasks():
    """Setup background tasks for maintenance"""
    
    async def cleanup_old_data():
        """Clean up old data periodically"""
        if not db:
            return
            
        try:
            # Remove data older than 90 days
            cutoff_date = datetime.now(timezone.utc).replace(day=1)  # Start of current month
            result = await db.status_checks.delete_many({
                "timestamp": {"$lt": cutoff_date.replace(month=cutoff_date.month-3)}
            })
            
            if result.deleted_count > 0:
                logger.info(f"🧹 Cleaned up {result.deleted_count} old records")
                
        except Exception as e:
            logger.error(f"❌ Cleanup task failed: {e}")
    
    # Schedule cleanup task (would need APScheduler in production)
    # For now, just log that it's available
    logger.info("🔄 Background cleanup task configured")

# Models
class StatusCheckBase(BaseModel):
    """Base model for status checks"""
    client_name: str = Field(..., min_length=1, max_length=100, description="Name of the client")
    
    @validator('client_name')
    def validate_client_name(cls, v):
        if not v or not v.strip():
            raise ValueError('Client name cannot be empty')
        # Clean the name
        clean_name = v.strip()
        if len(clean_name) < 1:
            raise ValueError('Client name too short')
        return clean_name

class StatusCheckCreate(StatusCheckBase):
    """Model for creating status checks"""
    pass

class StatusCheck(StatusCheckBase):
    """Complete status check model"""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

class StatusCheckResponse(StatusCheck):
    """Response model for status checks"""
    pass

class HealthCheck(BaseModel):
    """Health check response model"""
    status: str
    timestamp: datetime
    database: str
    version: str
    environment: str
    uptime: Optional[float] = None

class StatsResponse(BaseModel):
    """Statistics response model"""
    total_checks: int
    today_checks: int
    unique_clients: int
    top_clients: List[Dict[str, Any]]
    recent_activity: List[Dict[str, Any]]

class ErrorResponse(BaseModel):
    """Error response model"""
    detail: str
    error_code: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

# Middleware for rate limiting
@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Simple rate limiting middleware"""
    if not settings.ENABLE_RATE_LIMITING:
        return await call_next(request)
    
    client_ip = request.client.host
    current_time = time.time()
    
    # Clean old requests
    request_counts[client_ip] = [
        req_time for req_time in request_counts[client_ip]
        if current_time - req_time < 60  # Last minute
    ]
    
    # Check rate limit
    if len(request_counts[client_ip]) >= settings.MAX_REQUESTS_PER_MINUTE:
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded. Please try again later."}
        )
    
    # Add current request
    request_counts[client_ip].append(current_time)
    
    return await call_next(request)

# Middleware for request logging
@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """Log all requests"""
    start_time = time.time()
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    
    logger.info(
        f"{request.method} {request.url.path} - "
        f"Status: {response.status_code} - "
        f"Time: {process_time:.3f}s - "
        f"Client: {request.client.host}"
    )
    
    # Add timing header
    response.headers["X-Process-Time"] = str(process_time)
    
    return response

# Dependencies
async def get_database() -> AsyncIOMotorDatabase:
    """Dependency to get database connection"""
    if db is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database connection not available"
        )
    return db

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Dependency for authentication (placeholder)"""
    # In production, implement proper JWT validation
    return {"user_id": "anonymous"}

# Error handlers
@app.exception_handler(ConnectionFailure)
async def database_connection_handler(request: Request, exc: ConnectionFailure):
    """Handle database connection errors"""
    logger.error(f"Database connection error: {exc}")
    return JSONResponse(
        status_code=503,
        content=ErrorResponse(
            detail="Database connection unavailable",
            error_code="DB_CONNECTION_ERROR"
        ).dict()
    )

@app.exception_handler(OperationFailure)
async def database_operation_handler(request: Request, exc: OperationFailure):
    """Handle database operation errors"""
    logger.error(f"Database operation error: {exc}")
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            detail="Database operation failed",
            error_code="DB_OPERATION_ERROR"
        ).dict()
    )

@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content=ErrorResponse(
            detail="Internal server error",
            error_code="INTERNAL_ERROR"
        ).dict()
    )

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """Handle HTTP exceptions"""
    return JSONResponse(
        status_code=exc.status_code,
        content=ErrorResponse(
            detail=exc.detail,
            error_code=f"HTTP_{exc.status_code}"
        ).dict()
    )

# Create API router
api_router = APIRouter(prefix="/api", tags=["api"])

# Health check endpoints
@api_router.get("/health", response_model=HealthCheck)
async def health_check():
    """Comprehensive health check endpoint"""
    start_time = time.time()
    
    # Check database connection
    db_status = "disconnected"
    try:
        if db and client:
            await client.admin.command('ping')
            db_status = "connected"
    except Exception as e:
        logger.warning(f"Health check database ping failed: {e}")
        db_status = "error"
    
    return HealthCheck(
        status="healthy" if db_status == "connected" else "degraded",
        timestamp=datetime.now(timezone.utc),
        database=db_status,
        version="1.0.0",
        environment=settings.ENVIRONMENT,
        uptime=time.time() - start_time
    )

@api_router.get("/")
async def root():
    """API root endpoint with information"""
    return {
        "message": "ISA API - Intelligent Status Analytics",
        "version": "1.0.0",
        "environment": settings.ENVIRONMENT,
        "endpoints": {
            "health": "/api/health",
            "docs": "/docs" if settings.ENVIRONMENT != "production" else "disabled",
            "status": "/api/status"
        },
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

# Status check endpoints
@api_router.post("/status", response_model=StatusCheckResponse, status_code=status.HTTP_201_CREATED)
async def create_status_check(
    input_data: StatusCheckCreate,
    background_tasks: BackgroundTasks,
    database: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    """Create a new status check"""
    try:
        # Create status check object
        status_obj = StatusCheck(**input_data.dict())
        
        # Insert into database
        result = await database.status_checks.insert_one(status_obj.dict())
        
        if not result.inserted_id:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to create status check"
            )
        
        # Background task for analytics update
        background_tasks.add_task(update_analytics, status_obj.client_name)
        
        logger.info(f"✅ Created status check for client: {status_obj.client_name}")
        return StatusCheckResponse(**status_obj.dict())
        
    except Exception as e:
        logger.error(f"❌ Error creating status check: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to create status check: {str(e)}"
        )

@api_router.get("/status", response_model=List[StatusCheckResponse])
async def get_status_checks(
    limit: int = 1000,
    skip: int = 0,
    client_name: Optional[str] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    database: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    """Get status checks with filtering and pagination"""
    try:
        # Build query
        query = {}
        
        if client_name:
            query["client_name"] = {"$regex": client_name, "$options": "i"}
        
        if start_date or end_date:
            date_query = {}
            if start_date:
                date_query["$gte"] = start_date
            if end_date:
                date_query["$lte"] = end_date
            query["timestamp"] = date_query
        
        # Execute query with pagination
        cursor = database.status_checks.find(query)
        cursor = cursor.sort("timestamp", DESCENDING)
        cursor = cursor.skip(skip).limit(min(limit, 1000))  # Cap at 1000
        
        status_checks = await cursor.to_list(length=limit)
        
        # Convert to response models
        return [StatusCheckResponse(**check) for check in status_checks]
        
    except Exception as e:
        logger.error(f"❌ Error fetching status checks: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch status checks: {str(e)}"
        )

@api_router.get("/status/stats", response_model=StatsResponse)  
async def get_status_stats(
    database: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    """Get comprehensive statistics about status checks"""
    try:
        # Total count
        total_count = await database.status_checks.count_documents({})
        
        # Today's count
        today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        today_count = await database.status_checks.count_documents({
            "timestamp": {"$gte": today_start}
        })
        
        # Unique clients count
        unique_clients_pipeline = [
            {"$group": {"_id": "$client_name"}},
            {"$count": "unique_clients"}
        ]
        unique_clients_result = await database.status_checks.aggregate(unique_clients_pipeline).to_list(1)
        unique_clients = unique_clients_result[0]["unique_clients"] if unique_clients_result else 0
        
        # Top clients
        top_clients_pipeline = [
            {"$group": {"_id": "$client_name", "count": {"$sum": 1}}},
            {"$sort": {"count": DESCENDING}},
            {"$limit": 10}
        ]
        top_clients_cursor = database.status_checks.aggregate(top_clients_pipeline)
        top_clients = await top_clients_cursor.to_list(10)
        top_clients_formatted = [
            {"client_name": client["_id"], "count": client["count"]} 
            for client in top_clients
        ]
        
        # Recent activity (last 24 hours by hour)
        recent_activity_pipeline = [
            {
                "$match": {
                    "timestamp": {"$gte": datetime.now(timezone.utc).replace(hour=0, minute=0, second=0)}
                }
            },
            {
                "$group": {
                    "_id": {
                        "hour": {"$hour": "$timestamp"}
                    },
                    "count": {"$sum": 1}
                }
            },
            {"$sort": {"_id.hour": ASCENDING}}
        ]
        recent_activity_cursor = database.status_checks.aggregate(recent_activity_pipeline)
        recent_activity = await recent_activity_cursor.to_list(24)
        recent_activity_formatted = [
            {"hour": activity["_id"]["hour"], "count": activity["count"]}
            for activity in recent_activity
        ]
        
        return StatsResponse(
            total_checks=total_count,
            today_checks=today_count,
            unique_clients=unique_clients,
            top_clients=top_clients_formatted,
            recent_activity=recent_activity_formatted
        )
        
    except Exception as e:
        logger.error(f"❌ Error fetching stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch statistics: {str(e)}"
        )

@api_router.delete("/status/{status_id}")
async def delete_status_check(
    status_id: str,
    database: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    """Delete a status check by ID"""
    try:
        result = await database.status_checks.delete_one({"id": status_id})
        
        if result.deleted_count == 0:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Status check not found"
            )
        
        logger.info(f"🗑️ Deleted status check: {status_id}")
        return {"message": "Status check deleted successfully", "id": status_id}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error deleting status check: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete status check: {str(e)}"
        )

# Analytics endpoints
@api_router.get("/analytics/trends")
async def get_analytics_trends(
    days: int = 7,
    database: AsyncIOMotorDatabase = Depends(get_database),
    current_user: dict = Depends(get_current_user)
):
    """Get trend analysis for the specified number of days"""
    try:
        start_date = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        start_date = start_date.replace(day=start_date.day - days)
        
        pipeline = [
            {"$match": {"timestamp": {"$gte": start_date}}},
            {
                "$group": {
                    "_id": {
                        "year": {"$year": "$timestamp"},
                        "month": {"$month": "$timestamp"}, 
                        "day": {"$dayOfMonth": "$timestamp"}
                    },
                    "count": {"$sum": 1}
                }
            },
            {"$sort": {"_id.year": 1, "_id.month": 1, "_id.day": 1}}
        ]
        
        cursor = database.status_checks.aggregate(pipeline)
        trends = await cursor.to_list(days)
        
        formatted_trends = [
            {
                "date": f"{trend['_id']['year']}-{trend['_id']['month']:02d}-{trend['_id']['day']:02d}",
                "count": trend["count"]
            }
            for trend in trends
        ]
        
        return {"trends": formatted_trends, "period_days": days}
        
    except Exception as e:
        logger.error(f"❌ Error fetching trends: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to fetch trends: {str(e)}"
        )

# Background task functions
async def update_analytics(client_name: str):
    """Background task to update analytics"""
    try:
        # This would update cached analytics data
        logger.info(f"📊 Updated analytics for client: {client_name}")
    except Exception as e:
        logger.error(f"❌ Failed to update analytics: {e}")

# Include the API router
app.include_router(api_router)

# Serve static files in production
if settings.ENVIRONMENT == "production":
    static_path = ROOT_DIR / "build"
    if static_path.exists():
        app.mount("/static", StaticFiles(directory=static_path / "static"), name="static")
        
        @app.get("/{path:path}")
        async def serve_spa(path: str):
            """Serve React SPA for all non-API routes"""
            file_path = static_path / path
            if file_path.is_file():
                return FileResponse(file_path)
            return FileResponse(static_path / "index.html")

# Main entry point
if __name__ == "__main__":
    import uvicorn
    
    # Configure logging level
    log_level = settings.LOG_LEVEL.lower()
    
    logger.info(f"🚀 Starting ISA PWA API Server...")
    logger.info(f"📊 Environment: {settings.ENVIRONMENT}")
    logger.info(f"🌐 Host: {settings.HOST}:{settings.PORT}")
    logger.info(f"💾 Database: {settings.DB_NAME}")
    logger.info(f"📝 Log Level: {settings.LOG_LEVEL}")
    
    uvicorn.run(
        "server:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.ENVIRONMENT == "development",
        log_level=log_level,
        access_log=True,
        server_header=False,
        date_header=False
    )