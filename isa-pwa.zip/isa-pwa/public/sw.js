/**
 * ISA PWA Service Worker
 * Advanced service worker for caching, offline support, and background sync
 * Version: 1.0.0
 */

const CACHE_NAME = 'isa-pwa-v1.0.0';
const CACHE_VERSION = '1.0.0';
const STATIC_CACHE = `${CACHE_NAME}-static`;
const API_CACHE = `${CACHE_NAME}-api`;
const IMAGE_CACHE = `${CACHE_NAME}-images`;

// Files to cache immediately on install
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json',
  '/favicon.ico',
  '/logo192.png',
  '/logo512.png'
];

// API endpoints to cache
const API_ENDPOINTS = [
  '/api/status',
  '/api/health',
  '/api/status/stats'
];

// Cache strategies
const CACHE_STRATEGIES = {
  CACHE_FIRST: 'cache-first',
  NETWORK_FIRST: 'network-first', 
  STALE_WHILE_REVALIDATE: 'stale-while-revalidate',
  NETWORK_ONLY: 'network-only',
  CACHE_ONLY: 'cache-only'
};

// Cache configuration
const CACHE_CONFIG = {
  static: {
    strategy: CACHE_STRATEGIES.CACHE_FIRST,
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    maxEntries: 100
  },
  api: {
    strategy: CACHE_STRATEGIES.NETWORK_FIRST,
    maxAge: 5 * 60 * 1000, // 5 minutes
    maxEntries: 50
  },
  images: {
    strategy: CACHE_STRATEGIES.STALE_WHILE_REVALIDATE,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    maxEntries: 100
  }
};

// Utility functions
const log = (message, data = '') => {
  console.log(`[SW ${CACHE_VERSION}] ${message}`, data);
};

const isApiRequest = (url) => {
  return url.pathname.startsWith('/api/');
};

const isImageRequest = (url) => {
  return /\.(png|jpg|jpeg|svg|gif|webp|ico)$/i.test(url.pathname);
};

const isStaticAsset = (url) => {
  return url.pathname.startsWith('/static/') || 
         STATIC_ASSETS.includes(url.pathname) ||
         url.pathname === '/' ||
         url.pathname.endsWith('.html');
};

// Cache management
const getCacheName = (url) => {
  if (isApiRequest(url)) return API_CACHE;
  if (isImageRequest(url)) return IMAGE_CACHE;
  return STATIC_CACHE;
};

const getCacheStrategy = (url) => {
  if (isApiRequest(url)) return CACHE_CONFIG.api.strategy;
  if (isImageRequest(url)) return CACHE_CONFIG.images.strategy;
  return CACHE_CONFIG.static.strategy;
};

const shouldCache = (request, response) => {
  // Don't cache if not GET request
  if (request.method !== 'GET') return false;
  
  // Don't cache if response is not ok
  if (!response || response.status !== 200 || response.type !== 'basic') {
    return false;
  }
  
  // Don't cache if response is too large (>1MB)
  const contentLength = response.headers.get('content-length');
  if (contentLength && parseInt(contentLength) > 1024 * 1024) {
    return false;
  }
  
  return true;
};

// Cache strategies implementation
const cacheFirst = async (request, cacheName) => {
  const cachedResponse = await caches.match(request);
  if (cachedResponse) {
    log('Cache hit', request.url);
    return cachedResponse;
  }
  
  log('Cache miss, fetching from network', request.url);
  const response = await fetch(request);
  
  if (shouldCache(request, response)) {
    const cache = await caches.open(cacheName);
    cache.put(request, response.clone());
  }
  
  return response;
};

const networkFirst = async (request, cacheName) => {
  try {
    log('Network first attempt', request.url);
    const response = await fetch(request);
    
    if (shouldCache(request, response)) {
      const cache = await caches.open(cacheName);
      cache.put(request, response.clone());
    }
    
    return response;
  } catch (error) {
    log('Network failed, trying cache', request.url);
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
      return cachedResponse;
    }
    
    // Return offline page for navigation requests
    if (request.mode === 'navigate') {
      return caches.match('/');
    }
    
    throw error;
  }
};

const staleWhileRevalidate = async (request, cacheName) => {
  const cachedResponse = await caches.match(request);
  
  const fetchPromise = fetch(request).then(response => {
    if (shouldCache(request, response)) {
      const cache = caches.open(cacheName);
      cache.then(c => c.put(request, response.clone()));
    }
    return response;
  }).catch(() => {
    log('Network failed for stale-while-revalidate', request.url);
  });
  
  if (cachedResponse) {
    log('Serving from cache, updating in background', request.url);
    return cachedResponse;
  }
  
  log('No cache, waiting for network', request.url);
  return fetchPromise;
};

// Install event - cache static assets
self.addEventListener('install', event => {
  log('Installing service worker');
  
  event.waitUntil(
    (async () => {
      const cache = await caches.open(STATIC_CACHE);
      
      try {
        await cache.addAll(STATIC_ASSETS);
        log('Static assets cached successfully');
      } catch (error) {
        log('Failed to cache some static assets', error);
        // Cache assets individually to avoid complete failure
        for (const asset of STATIC_ASSETS) {
          try {
            await cache.add(asset);
          } catch (err) {
            log(`Failed to cache ${asset}`, err);
          }
        }
      }
      
      // Skip waiting to activate immediately
      self.skipWaiting();
    })()
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
  log('Activating service worker');
  
  event.waitUntil(
    (async () => {
      // Clean up old caches
      const cacheNames = await caches.keys();
      const oldCaches = cacheNames.filter(name => 
        name.startsWith('isa-pwa-') && name !== CACHE_NAME && 
        !name.startsWith(CACHE_NAME)
      );
      
      await Promise.all(
        oldCaches.map(cacheName => {
          log('Deleting old cache', cacheName);
          return caches.delete(cacheName);
        })
      );
      
      // Take control of all clients immediately
      await self.clients.claim();
      
      log('Service worker activated');
    })()
  );
});

// Fetch event - handle requests with caching strategies
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests and chrome-extension requests
  if (request.method !== 'GET' || url.protocol === 'chrome-extension:') {
    return;
  }
  
  const cacheName = getCacheName(url);
  const strategy = getCacheStrategy(url);
  
  event.respondWith(
    (async () => {
      try {
        switch (strategy) {
          case CACHE_STRATEGIES.CACHE_FIRST:
            return await cacheFirst(request, cacheName);
          
          case CACHE_STRATEGIES.NETWORK_FIRST:
            return await networkFirst(request, cacheName);
          
          case CACHE_STRATEGIES.STALE_WHILE_REVALIDATE:
            return await staleWhileRevalidate(request, cacheName);
          
          case CACHE_STRATEGIES.NETWORK_ONLY:
            return await fetch(request);
          
          case CACHE_STRATEGIES.CACHE_ONLY:
            return await caches.match(request) || new Response('Not found', { status: 404 });
          
          default:
            return await networkFirst(request, cacheName);
        }
      } catch (error) {
        log('Fetch error', error);
        
        // Fallback for navigation requests
        if (request.mode === 'navigate') {
          const fallback = await caches.match('/');
          if (fallback) {
            return fallback;
          }
        }
        
        // Return a generic offline response
        return new Response('Offline', { 
          status: 503,
          statusText: 'Service Unavailable',
          headers: { 'Content-Type': 'text/plain' }
        });
      }
    })()
  );
});

// Background sync for offline actions
self.addEventListener('sync', event => {
  log('Background sync event', event.tag);
  
  if (event.tag === 'background-sync') {
    event.waitUntil(syncOfflineActions());
  }
});

const syncOfflineActions = async () => {
  try {
    log('Starting background sync');
    
    // Get offline actions from storage
    const offlineActions = await getOfflineActions();
    
    for (const action of offlineActions) {
      try {
        const response = await fetch('/api/status', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(action.data)
        });
        
        if (response.ok) {
          await removeOfflineAction(action.id);
          log('Synced offline action', action.id);
          
          // Notify clients of successful sync
          const clients = await self.clients.matchAll();
          clients.forEach(client => {
            client.postMessage({
              type: 'SYNC_SUCCESS',
              actionId: action.id
            });
          });
        }
      } catch (error) {
        log('Failed to sync action', action.id, error);
      }
    }
    
    log('Background sync completed');
  } catch (error) {
    log('Background sync failed', error);
  }
};

// Offline actions management
const getOfflineActions = async () => {
  try {
    const clients = await self.clients.matchAll();
    if (clients.length > 0) {
      return new Promise((resolve) => {
        const channel = new MessageChannel();
        channel.port1.onmessage = (event) => {
          resolve(event.data || []);
        };
        
        clients[0].postMessage({
          type: 'GET_OFFLINE_ACTIONS'
        }, [channel.port2]);
      });
    }
    return [];
  } catch (error) {
    log('Failed to get offline actions', error);
    return [];
  }
};

const removeOfflineAction = async (actionId) => {
  try {
    const clients = await self.clients.matchAll();
    if (clients.length > 0) {
      clients[0].postMessage({
        type: 'REMOVE_OFFLINE_ACTION',
        actionId: actionId
      });
    }
  } catch (error) {
    log('Failed to remove offline action', error);
  }
};

// Push notifications
self.addEventListener('push', event => {
  log('Push notification received');
  
  let notificationData = {
    title: 'ISA PWA',
    body: 'You have a new notification',
    icon: '/logo192.png',
    badge: '/logo192.png'
  };
  
  if (event.data) {
    try {
      const data = event.data.json();
      notificationData = { ...notificationData, ...data };
    } catch (error) {
      log('Failed to parse push data', error);
    }
  }
  
  const options = {
    body: notificationData.body,
    icon: notificationData.icon,
    badge: notificationData.badge,
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: notificationData.primaryKey || '1'
    },
    actions: [
      {
        action: 'explore',
        title: 'View Details',
        icon: '/logo192.png'
      },
      {
        action: 'close',
        title: 'Close',
        icon: '/logo192.png'
      }
    ],
    requireInteraction: true,
    silent: false
  };
  
  event.waitUntil(
    self.registration.showNotification(notificationData.title, options)
  );
});

// Notification click handling
self.addEventListener('notificationclick', event => {
  log('Notification clicked', event.action);
  
  event.notification.close();
  
  if (event.action === 'close') {
    return;
  }
  
  event.waitUntil(
    self.clients.matchAll({ type: 'window' }).then(clients => {
      // Check if app is already open
      for (const client of clients) {
        if (client.url.includes('/') && 'focus' in client) {
          return client.focus();
        }
      }
      
      // Open new window if app not open
      if (self.clients.openWindow) {
        return self.clients.openWindow('/');
      }
    })
  );
});

// Message handling from main thread
self.addEventListener('message', event => {
  log('Message received', event.data);
  
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
  
  if (event.data && event.data.type === 'GET_VERSION') {
    event.ports[0].postMessage({
      version: CACHE_VERSION,
      cacheName: CACHE_NAME
    });
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => caches.delete(cacheName))
        );
      }).then(() => {
        event.ports[0].postMessage({ success: true });
      })
    );
  }
});

// Periodic background sync (if supported)
self.addEventListener('periodicsync', event => {
  log('Periodic sync event', event.tag);
  
  if (event.tag === 'content-sync') {
    event.waitUntil(syncOfflineActions());
  }
});

// Error handling
self.addEventListener('error', event => {
  log('Service worker error', event.error);
});

self.addEventListener('unhandledrejection', event => {
  log('Unhandled promise rejection in SW', event.reason);
});

// Log service worker registration
log(`Service worker registered successfully - Version ${CACHE_VERSION}`);