import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Performance monitoring
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

// Service Worker registration for PWA
const registerServiceWorker = () => {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js')
        .then(registration => {
          console.log('✅ Service Worker registered successfully:', registration);
          
          // Handle service worker updates
          registration.addEventListener('updatefound', () => {
            const newWorker = registration.installing;
            newWorker.addEventListener('statechange', () => {
              if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                // New content is available
                console.log('🔄 New version available');
                
                // Show update notification
                if (window.confirm('📱 Nuova versione disponibile! Vuoi ricaricare per aggiornare?')) {
                  window.location.reload();
                }
              }
            });
          });
          
          // Listen for service worker messages
          navigator.serviceWorker.addEventListener('message', event => {
            if (event.data && event.data.type === 'CACHE_UPDATED') {
              console.log('💾 Cache updated');
            }
          });
        })
        .catch(registrationError => {
          console.error('❌ Service Worker registration failed:', registrationError);
        });
    });
  } else {
    console.warn('⚠️ Service Worker not supported in this browser');
  }
};

// PWA Install prompt handling
const handlePWAInstall = () => {
  let deferredPrompt;
  
  window.addEventListener('beforeinstallprompt', (e) => {
    console.log('📱 PWA install prompt available');
    e.preventDefault();
    deferredPrompt = e;
    
    // Show custom install button (could be implemented in App component)
    window.dispatchEvent(new CustomEvent('pwa-installable', { detail: deferredPrompt }));
  });
  
  window.addEventListener('appinstalled', () => {
    console.log('🎉 PWA installed successfully');
    deferredPrompt = null;
    
    // Track installation
    if (window.gtag) {
      window.gtag('event', 'pwa_install', {
        event_category: 'PWA',
        event_label: 'App Installed'
      });
    }
  });
};

// Network status monitoring
const monitorNetworkStatus = () => {
  const updateNetworkStatus = () => {
    const isOnline = navigator.onLine;
    console.log(`🌐 Network status: ${isOnline ? 'Online' : 'Offline'}`);
    
    // Dispatch custom event for components to listen
    window.dispatchEvent(new CustomEvent('network-status-change', { 
      detail: { isOnline } 
    }));
    
    // Update body class for CSS styling
    document.body.classList.toggle('offline', !isOnline);
    document.body.classList.toggle('online', isOnline);
  };
  
  window.addEventListener('online', updateNetworkStatus);
  window.addEventListener('offline', updateNetworkStatus);
  
  // Initial status
  updateNetworkStatus();
};

// Theme detection and management
const initializeTheme = () => {
  // Check for saved theme or default to system preference
  const savedTheme = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  const theme = savedTheme || (prefersDark ? 'dark' : 'light');
  
  // Apply theme immediately to prevent flash
  document.documentElement.classList.toggle('dark', theme === 'dark');
  document.documentElement.setAttribute('data-theme', theme);
  
  console.log(`🎨 Theme initialized: ${theme}`);
  
  // Listen for system theme changes
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (!localStorage.getItem('theme')) {
      const newTheme = e.matches ? 'dark' : 'light';
      document.documentElement.classList.toggle('dark', e.matches);
      document.documentElement.setAttribute('data-theme', newTheme);
      console.log(`🎨 System theme changed: ${newTheme}`);
    }
  });
};

// Performance monitoring with Web Vitals
const reportWebVitals = (onPerfEntry) => {
  if (onPerfEntry && onPerfEntry instanceof Function) {
    getCLS(onPerfEntry);
    getFID(onPerfEntry);
    getFCP(onPerfEntry);
    getLCP(onPerfEntry);
    getTTFB(onPerfEntry);
  }
};

// Enhanced performance reporting
const setupPerformanceMonitoring = () => {
  const reportMetric = (metric) => {
    console.log(`📊 ${metric.name}: ${metric.value}`);
    
    // Send to analytics if available
    if (window.gtag) {
      window.gtag('event', metric.name, {
        event_category: 'Web Vitals',
        value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
        custom_parameter_1: metric.id,
        non_interaction: true,
      });
    }
    
    // Log to console in development
    if (process.env.NODE_ENV === 'development') {
      console.table([{
        Metric: metric.name,
        Value: metric.value,
        Rating: metric.rating,
        Delta: metric.delta,
        ID: metric.id
      }]);
    }
  };
  
  reportWebVitals(reportMetric);
};

// Error boundary for global error handling
const setupGlobalErrorHandling = () => {
  window.addEventListener('error', (event) => {
    console.error('🚨 Global error:', event.error);
    
    // Report to error tracking service
    if (window.gtag) {
      window.gtag('event', 'exception', {
        description: event.error?.message || 'Unknown error',
        fatal: false
      });
    }
  });
  
  window.addEventListener('unhandledrejection', (event) => {
    console.error('🚨 Unhandled promise rejection:', event.reason);
    
    // Report to error tracking service
    if (window.gtag) {
      window.gtag('event', 'exception', {
        description: event.reason?.message || 'Unhandled promise rejection',
        fatal: false
      });
    }
  });
};

// PWA display mode detection
const detectPWAMode = () => {
  const isPWA = window.matchMedia('(display-mode: standalone)').matches || 
                window.navigator.standalone || 
                document.referrer.includes('android-app://');
  
  if (isPWA) {
    console.log('📱 Running in PWA mode');
    document.body.classList.add('pwa-mode');
    document.documentElement.classList.add('pwa-mode');
    
    // Track PWA usage
    if (window.gtag) {
      window.gtag('event', 'pwa_usage', {
        event_category: 'PWA',
        event_label: 'Standalone Mode'
      });
    }
  } else {
    console.log('🌐 Running in browser mode');
    document.body.classList.add('browser-mode');
  }
};

// Hide loading screen after React loads
const hideLoadingScreen = () => {
  const loadingScreen = document.getElementById('loading-screen');
  if (loadingScreen) {
    // Wait for React to render, then hide loading
    setTimeout(() => {
      loadingScreen.classList.add('hidden');
      setTimeout(() => {
        loadingScreen.remove();
      }, 500);
    }, 1000);
  }
};

// Initialize all PWA features
const initializePWA = () => {
  console.log('🚀 Initializing ISA PWA...');
  
  // Initialize core features
  initializeTheme();
  registerServiceWorker();
  handlePWAInstall();
  monitorNetworkStatus();
  detectPWAMode();
  setupGlobalErrorHandling();
  setupPerformanceMonitoring();
  
  console.log('✅ ISA PWA initialized successfully');
};

// Main App Initialization
const initializeApp = () => {
  // Initialize PWA features
  initializePWA();
  
  // Create React root
  const container = document.getElementById('root');
  const root = ReactDOM.createRoot(container);
  
  // Enhanced error boundary wrapper
  const AppWithErrorBoundary = () => {
    return (
      <React.StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </React.StrictMode>
    );
  };
  
  // Render app
  root.render(<AppWithErrorBoundary />);
  
  // Hide loading screen
  hideLoadingScreen();
  
  console.log('🎉 ISA App rendered successfully');
};

// Simple Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }
  
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error('🚨 React Error Boundary caught an error:', error, errorInfo);
    
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
    
    // Report to error tracking
    if (window.gtag) {
      window.gtag('event', 'exception', {
        description: error.message,
        fatal: true
      });
    }
  }
  
  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          padding: '40px',
          textAlign: 'center',
          minHeight: '100vh',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        }}>
          <div style={{
            background: 'white',
            padding: '40px',
            borderRadius: '12px',
            boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)',
            maxWidth: '500px'
          }}>
            <h1 style={{ color: '#ef4444', marginBottom: '20px' }}>
              🚨 Oops! Qualcosa è andato storto
            </h1>
            <p style={{ color: '#6b7280', marginBottom: '20px' }}>
              L'applicazione ha riscontrato un errore imprevisto. 
              Il team è stato notificato automaticamente.
            </p>
            <button
              onClick={() => window.location.reload()}
              style={{
                background: '#3b82f6',
                color: 'white',
                border: 'none',
                padding: '12px 24px',
                borderRadius: '8px',
                cursor: 'pointer',
                fontSize: '16px'
              }}
            >
              🔄 Ricarica Pagina
            </button>
            
            {process.env.NODE_ENV === 'development' && (
              <details style={{ marginTop: '20px', textAlign: 'left' }}>
                <summary style={{ cursor: 'pointer', color: '#6b7280' }}>
                  Dettagli Errore (Solo Sviluppo)
                </summary>
                <pre style={{ 
                  background: '#f3f4f6', 
                  padding: '10px', 
                  borderRadius: '4px',
                  fontSize: '12px',
                  overflow: 'auto',
                  marginTop: '10px'
                }}>
                  {this.state.error && this.state.error.toString()}
                  <br />
                  {this.state.errorInfo.componentStack}
                </pre>
              </details>
            )}
          </div>
        </div>
      );
    }
    
    return this.props.children;
  }
}

// Start the application
try {
  initializeApp();
} catch (error) {
  console.error('🚨 Failed to initialize app:', error);
  
  // Fallback initialization
  document.addEventListener('DOMContentLoaded', () => {
    initializeApp();
  });
}

// Export for potential testing
export { reportWebVitals, initializePWA };