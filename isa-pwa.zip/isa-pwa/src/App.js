import React, { useState, useEffect, useCallback, useMemo, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import { 
  Activity, 
  Users, 
  BarChart3, 
  Settings, 
  Plus, 
  Trash2, 
  Clock,
  TrendingUp,
  Database,
  Wifi,
  WifiOff,
  Moon,
  Sun,
  Menu,
  X,
  AlertCircle,
  CheckCircle,
  Info,
  RefreshCw,
  Download,
  Share2
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import './App.css';

// API Configuration
const API_BASE_URL = process.env.NODE_ENV === 'production' 
  ? '/api' 
  : process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Constants
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const RETRY_ATTEMPTS = 3;
const RETRY_DELAY = 1000;

// API Service with enhanced error handling and caching
class APIService {
  static cache = new Map();
  static requestQueue = new Map();

  static async request(endpoint, options = {}) {
    const cacheKey = `${endpoint}-${JSON.stringify(options)}`;
    const cached = this.cache.get(cacheKey);
    
    // Return cached data if still valid
    if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
      return cached.data;
    }

    // Prevent duplicate requests
    if (this.requestQueue.has(cacheKey)) {
      return this.requestQueue.get(cacheKey);
    }

    const requestPromise = this.executeRequest(endpoint, options);
    this.requestQueue.set(cacheKey, requestPromise);

    try {
      const data = await requestPromise;
      
      // Cache successful responses
      this.cache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });
      
      return data;
    } finally {
      this.requestQueue.delete(cacheKey);
    }
  }

  static async executeRequest(endpoint, options = {}) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
        },
        signal: controller.signal,
        ...options,
      });
      
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.detail || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error.name === 'AbortError') {
        throw new Error('Request timeout - please check your connection');
      }
      
      throw error;
    }
  }

  static async getStatusChecks(params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const endpoint = `/status${queryString ? `?${queryString}` : ''}`;
    return this.request(endpoint);
  }

  static async createStatusCheck(data) {
    return this.request('/status', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  static async deleteStatusCheck(id) {
    return this.request(`/status/${id}`, {
      method: 'DELETE',
    });
  }

  static async getStatistics() {
    return this.request('/status/stats');
  }

  static async testConnection() {
    try {
      await this.request('/health');
      return true;
    } catch {
      return false;
    }
  }

  static clearCache() {
    this.cache.clear();
  }
}

// Custom Hooks
const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return initialValue;
    }
  });

  const setValue = useCallback((value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.warn(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue]);

  return [storedValue, setValue];
};

const useNetworkStatus = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Custom network status event
    const handleNetworkStatusChange = (event) => {
      setIsOnline(event.detail.isOnline);
    };

    window.addEventListener('network-status-change', handleNetworkStatusChange);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('network-status-change', handleNetworkStatusChange);
    };
  }, []);

  return isOnline;
};

const useTheme = () => {
  const [theme, setTheme] = useLocalStorage('theme', 'system');

  const actualTheme = useMemo(() => {
    if (theme === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return theme;
  }, [theme]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', actualTheme === 'dark');
    document.documentElement.setAttribute('data-theme', actualTheme);
  }, [actualTheme]);

  const toggleTheme = useCallback(() => {
    setTheme(current => {
      if (current === 'light') return 'dark';
      if (current === 'dark') return 'system';
      return 'light';
    });
  }, [setTheme]);

  return { theme, actualTheme, toggleTheme };
};

// Toast Notification System
const ToastContext = React.createContext();

const ToastProvider = ({ children }) => {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'info', duration = 5000) => {
    const id = Date.now();
    const toast = { id, message, type, duration };
    
    setToasts(current => [...current, toast]);
    
    if (duration > 0) {
      setTimeout(() => {
        setToasts(current => current.filter(t => t.id !== id));
      }, duration);
    }
    
    return id;
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(current => current.filter(t => t.id !== id));
  }, []);

  const value = { toasts, addToast, removeToast };
  
  return (
    <ToastContext.Provider value={value}>
      {children}
      <ToastContainer toasts={toasts} onRemove={removeToast} />
    </ToastContext.Provider>
  );
};

const useToast = () => {
  const context = React.useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

// Toast Container Component
const ToastContainer = ({ toasts, onRemove }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="toast-container">
      {toasts.map(toast => (
        <Toast key={toast.id} {...toast} onClose={() => onRemove(toast.id)} />
      ))}
    </div>
  );
};

const Toast = ({ id, message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000);
    return () => clearTimeout(timer);
  }, [onClose]);

  const icons = {
    success: CheckCircle,
    error: AlertCircle,
    warning: AlertCircle,
    info: Info
  };

  const Icon = icons[type] || Info;

  return (
    <div className={`toast show ${type} animate-slide-in-right`}>
      <div className="flex items-start gap-3">
        <Icon size={20} className="flex-shrink-0 mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-medium">{message}</p>
        </div>
        <button
          onClick={onClose}
          className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X size={16} />
        </button>
      </div>
    </div>
  );
};

// Loading Component
const LoadingSpinner = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  };

  return (
    <div className={`loading-spinner ${sizeClasses[size]} ${className}`} />
  );
};

const LoadingSkeleton = ({ className = '', count = 1 }) => {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <div key={index} className={`skeleton ${className}`} />
      ))}
    </>
  );
};

// Header Component
const Header = ({ isOnline, onToggleOffline, theme, onToggleTheme }) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const getPageTitle = () => {
    switch (location.pathname) {
      case '/': return 'Dashboard';
      case '/analytics': return 'Analytics';
      case '/settings': return 'Settings';
      default: return 'ISA';
    }
  };

  const themeIcons = {
    light: Sun,
    dark: Moon,
    system: Activity
  };

  const ThemeIcon = themeIcons[theme] || Activity;

  return (
    <header className="App-header bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-700 safe-area-top sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <h1 className="text-2xl font-bold isa-logo">ISA</h1>
            </Link>
            <div className="hidden md:block ml-6">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white">
                {getPageTitle()}
              </h2>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 focus-ring"
              title={`Theme: ${theme}`}
            >
              <ThemeIcon size={20} />
            </button>

            {/* Connection Status */}
            <button
              onClick={onToggleOffline}
              className={`p-2 rounded-lg transition-colors focus-ring ${
                isOnline 
                  ? 'text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20' 
                  : 'text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20'
              }`}
              title={isOnline ? 'Online - Click to simulate offline' : 'Offline - Click to reconnect'}
            >
              {isOnline ? <Wifi size={20} /> : <WifiOff size={20} />}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800 focus-ring"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex flex-col space-y-2">
              <h2 className="text-lg font-medium text-gray-900 dark:text-white px-2">
                {getPageTitle()}
              </h2>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

// Navigation Component
const Navigation = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', icon: Activity, label: 'Dashboard' },
    { path: '/analytics', icon: BarChart3, label: 'Analytics' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <nav className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 safe-area-bottom sticky bottom-0 z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-around">
          {navItems.map(({ path, icon: Icon, label }) => (
            <Link
              key={path}
              to={path}
              className={`nav-link flex flex-col items-center py-3 px-4 text-sm font-medium rounded-lg transition-all duration-200 touch-friendly ${
                location.pathname === path
                  ? 'text-blue-600 bg-blue-50 dark:text-blue-400 dark:bg-blue-900/20 active'
                  : 'text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white hover:bg-gray-50 dark:hover:bg-gray-800'
              }`}
            >
              <Icon size={20} />
              <span className="mt-1">{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

// Dashboard Component
const Dashboard = ({ statusChecks, onCreateStatus, isOnline, onRefresh, isLoading }) => {
  const [newClientName, setNewClientName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { addToast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!newClientName.trim()) {
      addToast('Please enter a client name', 'warning');
      return;
    }
    
    setIsSubmitting(true);
    try {
      await onCreateStatus({ client_name: newClientName.trim() });
      setNewClientName('');
      addToast('Status check created successfully!', 'success');
    } catch (error) {
      console.error('Error creating status:', error);
      addToast(`Failed to create status check: ${error.message}`, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const stats = useMemo(() => {
    const totalChecks = statusChecks.length;
    const todayChecks = statusChecks.filter(check => 
      new Date(check.timestamp).toDateString() === new Date().toDateString()
    ).length;
    const uniqueClients = new Set(statusChecks.map(check => check.client_name)).size;
    const recentChecks = statusChecks.slice(-5).reverse();

    return { totalChecks, todayChecks, uniqueClients, recentChecks };
  }, [statusChecks]);

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="stat-card animate-pulse">
              <LoadingSkeleton className="h-16 w-full" />
            </div>
          ))}
        </div>
        <LoadingSkeleton className="h-32 w-full mb-8" />
        <LoadingSkeleton className="h-