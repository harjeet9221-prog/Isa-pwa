#!/bin/bash

# ISA PWA - Script di avvio
# Descrizione: Avvia l'applicazione ISA in modalità sviluppo o produzione

set -e

# Colori per output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funzioni di utilità
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verifica prerequisiti
check_prerequisites() {
    log_info "Verifica prerequisiti..."
    
    # Node.js
    if ! command -v node &> /dev/null; then
        log_error "Node.js non trovato. Installa Node.js 18+ da https://nodejs.org"
        exit 1
    fi
    
    local node_version=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$node_version" -lt 16 ]; then
        log_error "Node.js versione $node_version trovata. Richiesta versione 18+"
        exit 1
    fi
    
    # Python
    if ! command -v python3 &> /dev/null; then
        log_error "Python3 non trovato. Installa Python 3.11+ da https://python.org"
        exit 1
    fi
    
    # MongoDB (opzionale per sviluppo)
    if ! command -v mongod &> /dev/null; then
        log_warning "MongoDB non trovato. Assicurati di avere MongoDB in esecuzione o usa Docker"
    fi
    
    log_success "Prerequisiti verificati"
}

# Setup ambiente
setup_environment() {
    log_info "Setup ambiente..."
    
    # Crea file .env se non esiste
    if [ ! -f ".env" ]; then
        log_info "Creazione file .env da template..."
        cp .env.example .env
        log_warning "Modifica il file .env con le tue configurazioni"
    fi
    
    # Installa dipendenze Node.js
    if [ ! -d "node_modules" ]; then
        log_info "Installazione dipendenze frontend..."
        npm install
    fi
    
    # Installa dipendenze Python
    if [ ! -d "venv" ]; then
        log_info "Creazione virtual environment Python..."
        python3 -m venv venv
    fi
    
    log_info "Attivazione virtual environment e installazione dipendenze..."
    source venv/bin/activate
    pip install -r requirements.txt
    
    log_success "Ambiente configurato"
}

# Avvia in modalità sviluppo
start_dev() {
    log_info "Avvio in modalità sviluppo..."
    
    # Verifica MongoDB
    if ! pgrep mongod > /dev/null; then
        log_warning "MongoDB non in esecuzione. Tentativo di avvio..."
        if command -v brew &> /dev/null; then
            brew services start mongodb-community || log_warning "Impossibile avviare MongoDB con brew"
        elif command -v systemctl &> /dev/null; then
            sudo systemctl start mongod || log_warning "Impossibile avviare MongoDB con systemctl"
        else
            log_warning "Avvia MongoDB manualmente o usa Docker: docker run -d -p 27017:27017 mongo:7"
        fi
    fi
    
    # Avvia backend in background
    log_info "Avvio server FastAPI..."
    source venv/bin/activate
    python server.py &
    BACKEND_PID=$!
    
    # Attendi che il backend sia pronto
    sleep 3
    
    # Avvia frontend
    log_info "Avvio server React..."
    npm start &
    FRONTEND_PID=$!
    
    # Trap per cleanup
    trap 'log_info "Arresto servizi..."; kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; exit 0' INT TERM
    
    log_success "Applicazione avviata!"
    log_info "Frontend: http://localhost:3000"
    log_info "Backend: http://localhost:8000"
    log_info "API Docs: http://localhost:8000/docs"
    log_info "Premi Ctrl+C per arrestare"
    
    # Attendi processi
    wait
}

# Avvia con Docker
start_docker() {
    log_info "Avvio con Docker..."
    
    if ! command -v docker &> /dev/null; then
        log_error "Docker non trovato. Installa Docker da https://docker.com"
        exit 1
    fi
    
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose non trovato. Installa Docker Compose"
        exit 1
    fi
    
    # Build e avvio
    log_info "Build e avvio container..."
    docker-compose up --build -d
    
    # Attendi che i servizi siano pronti
    log_info "Attesa avvio servizi..."
    sleep 10
    
    # Verifica salute servizi
    if docker-compose ps | grep -q "unhealthy\|Exit"; then
        log_error "Alcuni servizi non sono sani. Controlla i logs:"
        docker-compose logs
        exit 1
    fi
    
    log_success "Applicazione avviata con Docker!"
    log_info "URL: http://localhost:8000"
    log_info "Logs: docker-compose logs -f"
    log_info "Stop: docker-compose down"
}

# Build per produzione
build_production() {
    log_info "Build per produzione..."
    
    # Build frontend
    log_info "Build frontend..."
    npm run build
    
    # Verifica build
    if [ ! -d "build" ]; then
        log_error "Build frontend fallita"
        exit 1
    fi
    
    log_success "Build completata. File in ./build/"
}

# Test
run_tests() {
    log_info "Esecuzione test..."
    
    # Test frontend
    log_info "Test frontend..."
    npm test -- --coverage --watchAll=false
    
    # Test backend
    log_info "Test backend..."
    source venv/bin/activate
    python -m pytest --cov=. --cov-report=html
    
    log_success "Test completati"
}

# Menu principale
show_menu() {
    echo ""
    echo "🚀 ISA PWA - Intelligent Status Analytics"
    echo "========================================="
    echo "1) Setup iniziale"
    echo "2) Sviluppo (dev mode)"
    echo "3) Docker (produzione)"
    echo "4) Build produzione"
    echo "5) Esegui test"
    echo "6) Esci"
    echo ""
}

# Main
main() {
    cd "$(dirname "$0")/.."
    
    case "${1:-menu}" in
        "setup")
            check_prerequisites
            setup_environment
            ;;
        "dev")
            check_prerequisites
            setup_environment
            start_dev
            ;;
        "docker")
            start_docker
            ;;
        "build")
            check_prerequisites
            build_production
            ;;
        "test")
            check_prerequisites
            run_tests
            ;;
        "menu")
            while true; do
                show_menu
                read -p "Scegli un'opzione: " choice
                case $choice in
                    1)
                        check_prerequisites
                        setup_environment
                        ;;
                    2)
                        check_prerequisites
                        setup_environment
                        start_dev
                        ;;
                    3)
                        start_docker
                        ;;
                    4)
                        check_prerequisites
                        build_production
                        ;;
                    5)
                        check_prerequisites
                        run_tests
                        ;;
                    6)
                        log_info "Arrivederci!"
                        exit 0
                        ;;
                    *)
                        log_error "Opzione non valida"
                        ;;
                esac
                echo ""
                read -p "Premi Enter per continuare..."
            done
            ;;
        *)
            echo "Uso: $0 {setup|dev|docker|build|test|menu}"
            echo ""
            echo "Comandi:"
            echo "  setup  - Setup iniziale ambiente"
            echo "  dev    - Avvia in modalità sviluppo"
            echo "  docker - Avvia con Docker"
            echo "  build  - Build per produzione"
            echo "  test   - Esegui test"
            echo "  menu   - Menu interattivo"
            exit 1
            ;;
    esac
}

# Avvia script
main "$@"