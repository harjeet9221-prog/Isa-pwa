# ISA - Intelligent Status Analytics

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![React](https://img.shields.io/badge/React-18.2.0-blue.svg)](https://reactjs.org/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110.1-green.svg)](https://fastapi.tiangolo.com/)
[![MongoDB](https://img.shields.io/badge/MongoDB-7.0-green.svg)](https://www.mongodb.com/)

Una Progressive Web App (PWA) moderna per il monitoraggio intelligente dello stato e l'analisi dei dati, costruita con React, FastAPI e MongoDB.

## 🚀 Caratteristiche

- **📱 Progressive Web App**: Installabile su dispositivi mobili e desktop
- **🌙 Dark Mode**: Supporto per tema scuro/chiaro
- **📊 Analytics**: Dashboard con grafici interattivi
- **🔄 Offline Support**: Funzionalità offline con sincronizzazione automatica
- **📈 Real-time Data**: Aggiornamenti in tempo reale
- **🎨 Modern UI**: Design responsive con Tailwind CSS
- **🔒 Sicuro**: API protette con validazione dati
- **🐳 Docker Ready**: Containerizzazione completa

## 🛠 Stack Tecnologico

### Frontend
- **React 18** - UI Framework
- **Tailwind CSS** - Styling
- **Recharts** - Grafici e visualizzazioni
- **Lucide React** - Icone
- **React Router** - Routing

### Backend
- **FastAPI** - API Framework
- **MongoDB** - Database NoSQL
- **Motor** - Driver MongoDB asincrono
- **Pydantic** - Validazione dati
- **Uvicorn** - Server ASGI

### DevOps
- **Docker** - Containerizzazione
- **Docker Compose** - Orchestrazione
- **Nginx** - Reverse Proxy
- **Redis** - Caching (opzionale)

## 📦 Installazione

### Prerequisiti
- Node.js 18+ 
- Python 3.11+
- MongoDB 7+
- Docker & Docker Compose (opzionale)

### Installazione Locale

1. **Clone del repository**
```bash
git clone https://github.com/username/isa-pwa.git
cd isa-pwa
```

2. **Setup Backend**
```bash
# Installa dipendenze Python
pip install -r requirements.txt

# Copia e configura variabili ambiente
cp .env.example .env
# Modifica .env con le tue configurazioni

# Avvia MongoDB (se non già in esecuzione)
mongod

# Avvia il server FastAPI
python server.py
```

3. **Setup Frontend**
```bash
# Installa dipendenze Node.js
npm install

# Avvia l'app React
npm start
```

L'applicazione sarà disponibile su:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- Documentazione API: http://localhost:8000/docs

### Installazione con Docker

```bash
# Clone del repository
git clone https://github.com/username/isa-pwa.git
cd isa-pwa

# Avvia tutti i servizi
docker-compose up -d

# Visualizza i logs
docker-compose logs -f
```

L'applicazione sarà disponibile su http://localhost:8000

## 🔧 Configurazione

### Variabili Ambiente

Crea un file `.env` basato su `.env.example`:

```bash
# Database
MONGO_URL=mongodb://localhost:27017
DB_NAME=isa_db

# Environment
ENVIRONMENT=development
HOST=0.0.0.0
PORT=8000

# Security (opzionale)
SECRET_KEY=your-secret-key
JWT_ALGORITHM=HS256
```

### MongoDB Setup

Se usi MongoDB locale, assicurati che sia in esecuzione:

```bash
# macOS (con Homebrew)
brew services start mongodb-community

# Ubuntu/Debian
sudo systemctl start mongod

# Windows
net start MongoDB
```

## 📱 Caratteristiche PWA

### Installazione App
L'app può essere installata come applicazione nativa su:
- 📱 Dispositivi iOS (Safari)
- 🤖 Dispositivi Android (Chrome)
- 💻 Desktop (Chrome, Edge, Firefox)

### Funzionalità Offline
- ✅ Caching delle risorse statiche
- ✅ Funzionalità base offline
- ✅ Sincronizzazione automatica quando torna online
- ✅ Notifiche push (future)

## 🎯 Utilizzo

### Dashboard
- Visualizza statistiche in tempo reale
- Crea nuovi status check
- Monitora attività recenti

### Analytics
- Grafici delle tendenze settimanali
- Statistiche dei clienti più attivi
- Analisi delle performance

### Settings
- Toggle dark/light mode
- Stato connessione
- Gestione dati locali
- Informazioni app

## 🚀 API Endpoints

### Status Checks
```bash
# Ottieni tutti gli status check
GET /api/status

# Crea nuovo status check
POST /api/status
{
  "client_name": "Nome Cliente"
}

# Ottieni statistiche
GET /api/status/stats

# Elimina status check
DELETE /api/status/{id}
```

### Health & Info
```bash
# Health check
GET /api/health

# Info API
GET /api/
```

Documentazione completa disponibile su `/docs` (Swagger UI)

## 🧪 Testing

```bash
# Test Backend
python -m pytest

# Test Frontend
npm test

# Test Coverage
npm run test:coverage
```

## 🚀 Deployment

### Deploy su Heroku

```bash
# Login e crea app
heroku login
heroku create isa-pwa

# Configura variabili ambiente
heroku config:set MONGO_URL=your-mongodb-url
heroku config:set ENVIRONMENT=production

# Deploy
git push heroku main
```

### Deploy su Vercel (Frontend)

```bash
npm install -g vercel
vercel --prod
```

### Deploy su DigitalOcean App Platform

1. Connetti repository GitHub
2. Configura variabili ambiente
3. Deploy automatico

## 🔒 Sicurezza

- ✅ Validazione input con Pydantic
- ✅ CORS configurato correttamente
- ✅ Rate limiting (implementabile)
- ✅ Sanitizzazione dati
- ✅ HTTPS ready
- ✅ Environment variables per secrets
- ✅ Database indexing per performance

## 🔧 Sviluppo

### Setup Ambiente di Sviluppo

```bash
# Clone e setup
git clone https://github.com/username/isa-pwa.git
cd isa-pwa

# Virtual environment Python
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Installa dipendenze
pip install -r requirements.txt
npm install

# Setup pre-commit hooks
pip install pre-commit
pre-commit install
```

### Struttura Progetto

```
isa-pwa/
├── 📁 public/              # File statici React
│   ├── manifest.json       # PWA manifest
│   ├── sw.js               # Service Worker
│   └── index.html          # HTML template
├── 📁 src/                 # Codice sorgente React
│   ├── App.js              # Componente principale
│   ├── App.css             # Stili principali
│   └── index.css           # Stili globali
├── 📁 backend/             # Backend FastAPI
│   ├── server.py           # Server principale
│   ├── __init__.py         # Init module
│   └── requirements.txt    # Dipendenze Python
├── 📁 docker/              # Configurazione Docker
│   ├── Dockerfile          # Container app
│   └── docker-compose.yml  # Orchestrazione
├── 📁 docs/                # Documentazione
├── 📁 tests/               # Test suite
│   ├── test_api.py         # Test API
│   └── test_frontend.py    # Test frontend
├── .env.example            # Template variabili ambiente
├── .gitignore              # File ignorati da Git
├── package.json            # Dipendenze Node.js
├── tailwind.config.js      # Configurazione Tailwind
└── README.md               # Documentazione principale
```

### Comandi Utili

```bash
# Sviluppo
npm start                   # Avvia dev server React
python server.py            # Avvia server FastAPI
npm run build              # Build produzione

# Docker
docker-compose up -d        # Avvia tutti i servizi
docker-compose logs -f      # Visualizza logs
docker-compose down         # Ferma servizi

# Database
mongosh                     # Connetti a MongoDB
mongodump --db isa_db       # Backup database
mongorestore --db isa_db    # Restore database

# Testing
npm test                    # Test frontend
python -m pytest           # Test backend
npm run test:e2e           # Test end-to-end
```

## 📊 Monitoring & Logging

### Logging
- 📝 Structured logging con Python logging
- 📈 Request/response logging
- 🚨 Error tracking
- 📊 Performance metrics

### Health Checks
- 💗 `/api/health` endpoint
- 🔍 Database connectivity check
- 📊 System metrics
- 🚨 Alerting configurabile

## 🔄 CI/CD Pipeline

### GitHub Actions

```yaml
# .github/workflows/main.yml
name: CI/CD Pipeline
on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - uses: actions/setup-python@v3
      - run: npm install && npm test
      - run: pip install -r requirements.txt && pytest

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - name: Deploy to production
        run: # deployment script
```

## 🌍 Internazionalizzazione

### Supporto Multi-lingua (Future)
- 🇮🇹 Italiano (default)
- 🇺🇸 Inglese
- 🇪🇸 Spagnolo
- 🇫🇷 Francese

```bash
# Aggiungere react-i18next
npm install react-i18next i18next
```

## 📈 Roadmap

### v1.1 (Prossima Release)
- [ ] 🔐 Autenticazione JWT
- [ ] 👥 Multi-tenancy
- [ ] 📧 Notifiche email
- [ ] 📱 Notifiche push
- [ ] 🔍 Ricerca avanzata
- [ ] 📤 Export dati

### v1.2 (Future)
- [ ] 🤖 AI Analytics
- [ ] 📊 Dashboard personalizzabili
- [ ] 🔗 Integrazioni API terze parti
- [ ] 📱 App mobile nativa
- [ ] 🌐 Multi-lingua
- [ ] 📈 Advanced metrics

## 🤝 Contributing

### Come Contribuire

1. **Fork** il repository
2. **Crea** un branch per la feature (`git checkout -b feature/amazing-feature`)
3. **Commit** le modifiche (`git commit -m 'Add amazing feature'`)
4. **Push** al branch (`git push origin feature/amazing-feature`)
5. **Apri** una Pull Request

### Guidelines

- 📝 Segui le convenzioni di naming
- ✅ Aggiungi test per nuove feature
- 📚 Aggiorna la documentazione
- 🎨 Mantieni il coding style consistente
- 🔍 Testa thoroughly prima del commit

### Code Style

```bash
# Frontend (Prettier + ESLint)
npm run lint
npm run format

# Backend (Black + isort)
black .
isort .
flake8 .
```

## 📞 Supporto

### Hai problemi?

- 📖 Controlla la [documentazione](docs/)
- 🐛 Apri un [issue](https://github.com/username/isa-pwa/issues)
- 💬 Discussioni [GitHub Discussions](https://github.com/username/isa-pwa/discussions)
- 📧 Email: support@isa-app.com

### FAQ

**Q: Come resetto il database?**
```bash
mongosh isa_db --eval "db.dropDatabase()"
```

**Q: L'app non si installa come PWA?**
- Verifica che sia servita su HTTPS
- Controlla che manifest.json sia valido
- Assicurati che il Service Worker sia registrato

**Q: Errore di connessione al database?**
- Verifica che MongoDB sia in esecuzione
- Controlla la stringa di connessione in `.env`
- Verifica le autorizzazioni del database

## 📄 Licenza

Questo progetto è rilasciato sotto la licenza MIT. Vedi il file [LICENSE](LICENSE) per i dettagli.

```
MIT License

Copyright (c) 2024 ISA Team

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## 🙏 Ringraziamenti

- [React](https://reactjs.org/) - UI Framework
- [FastAPI](https://fastapi.tiangolo.com/) - Backend Framework
- [MongoDB](https://www.mongodb.com/) - Database
- [Tailwind CSS](https://tailwindcss.com/) - CSS Framework
- [Lucide](https://lucide.dev/) - Icons
- [Recharts](https://recharts.org/) - Charts Library

---

<div align="center">

**[⬆ Torna all'inizio](#isa---intelligent-status-analytics)**

Made with ❤️ by ISA Team

</div>